<?php

require_once("dbconnect.php");

if (isset($_POST["search"])) {
  $content = $_POST["content"];
  $id1 = isset($_POST["id1"]) ? $_POST["id1"] : 0;
  $id2 = isset($_POST["id2"]) ? $_POST["id2"] : 0;
  $output = "";
  
  $regex3 = new MongoDB\BSON\Regex($content, "i");
  $filter2 = ['$and' => [["userid" => (int)$id1], ["content" => $regex3]]];
  $options2 = [];

  $query2 = new MongoDB\Driver\Query($filter2, $options2);
  $cursor2 = $m->executeQuery('peoplefinder.osn1_content', $query2);
  $pfound = false;
  foreach ($cursor2 as $document2) {
    $pfound = true;
    $instant = date_create_from_format('Y-m-d H:i:s', $document2->instant);
    $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $instant->format("d F Y | h:i A") . '</h2></div><div class="mdl-card__supporting-text">' . $document2->content . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></button></div></div>';
  }
  if (!$pfound) {
    $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No posts on&nbsp;<img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></h2></div></div>';
  }
  
  $filter2 = ['$and' => [["userid" => (int)$id2], ["content" => $regex3]]];
  $options2 = [];

  $query2 = new MongoDB\Driver\Query($filter2, $options2);
  $cursor2 = $m->executeQuery('peoplefinder.osn2_content', $query2);
  $pfound = false;
  foreach ($cursor2 as $document2) {
    $pfound = true;
    $instant = date_create_from_format('Y-m-d H:i:s', $document2->instant);
    $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $instant->format("d F Y | h:i A") . '</h2></div><div class="mdl-card__supporting-text">' . $document2->content . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="linkedin-logo.png" class="osn-logo" /></button></div></div>';
  }
  if (!$pfound) {
    $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No posts on&nbsp;<img src="linkedin-logo.png" class="osn-logo" /></h2></div></div>';
  }
  
  /*if ($id1 != 0) {
    $sql = $conn->prepare("SELECT id, FirstName, LastName, Email, WorkingAt, LivingIn, FromPlace, Birthday, StudiedAt, Link FROM OSN1 WHERE id = ?;");
    $sql->bind_param("i", $id1);
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      $fname = $row["FirstName"];
      $lname = $row["LastName"];
      $email = $row["Email"];
      $works = $row["WorkingAt"];
      $lives = $row["LivingIn"];
      $dob = $row["Birthday"];
      $studied = $row["StudiedAt"];
      $query = "SELECT Content, Instant FROM osn1_content WHERE LOWER(Content) LIKE ('%" . strtolower($content) . "%') AND UserId = ?";
      //echo $query;
      $sql = $conn->prepare($query);
      $sql->bind_param("i", $id1);
      $sql->execute();
      $result = $sql->get_result();
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $instant = date_create_from_format('Y-m-d H:i:s', $row["Instant"]);
          $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $instant->format("d F Y | h:i A") . '</h2></div><div class="mdl-card__supporting-text">' . $row["Content"] . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></button></div></div>';
        }
      } else {
        $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No posts on&nbsp;<img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></h2></div></div>';
      }
      $query = "SELECT Content, Instant FROM OSN2, osn2_content o2 WHERE FirstName LIKE ('%". $fname . "%') AND LastName LIKE ('%" . $lname . "%') AND (Email LIKE ('%". $email . "%') OR Email = '') AND (WorkingAt LIKE ('%". $works . "%') OR WorkingAt = '') AND (LivingIn LIKE ('%". $lives . "%') OR LivingIn = '') AND (Birthday LIKE ('%". $dob . "%') OR Birthday = '') AND (StudiedAt LIKE ('%". $studied . "%') OR StudiedAt = '') AND LOWER(Content) LIKE ('%" . strtolower($content) . "%') AND OSN2.id = o2.UserId;";
      //echo $query;
      $sql = $conn->prepare($query);
      $sql->execute();
      $result = $sql->get_result();
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $instant = date_create_from_format('Y-m-d H:i:s', $row["Instant"]);
          $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $instant->format("d F Y | h:i A") . '</h2></div><div class="mdl-card__supporting-text">' . $row["Content"] . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="linkedin-logo.png" class="osn-logo" /></button></div></div>';
        }
      }  else {
        $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No posts on&nbsp;<img src="linkedin-logo.png" class="osn-logo" /></h2></div></div>';
      }
    } else {
      $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No results!</h2></div></div>';
    }
  } else if ($id2 != 0) {
    $sql = $conn->prepare("SELECT id, FirstName, LastName, Email, WorkingAt, LivingIn, Birthday, StudiedAt, Link FROM OSN2 WHERE id = ?;");
    $sql->bind_param("i", $id2);
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      $fname = $row["FirstName"];
      $lname = $row["LastName"];
      $email = $row["Email"];
      $works = $row["WorkingAt"];
      $lives = $row["LivingIn"];
      $dob = $row["Birthday"];
      $studied = $row["StudiedAt"];
      $query = "SELECT Content, Instant FROM osn2_content WHERE LOWER(Content) LIKE ('%" . strtolower($content) . "%') AND UserId = ?";
      //echo $query;
      $sql = $conn->prepare($query);
      $sql->bind_param("i", $id2);
      $sql->execute();
      $result = $sql->get_result();
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $instant = date_create_from_format('Y-m-d H:i:s', $row["Instant"]);
          $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $instant->format("d F Y | h:i A") . '</h2></div><div class="mdl-card__supporting-text">' . $row["Content"] . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="linkedin-logo.png" class="osn-logo" /></button></div></div>';
        }
      } else {
        $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No posts on&nbsp;<img src="linkedin-logo.png" class="osn-logo" /></h2></div></div>';
      }
      $query = "SELECT Content, Instant FROM OSN1, osn1_content o1 WHERE FirstName LIKE ('%". $fname . "%') AND LastName LIKE ('%" . $lname . "%') AND (Email LIKE ('%". $email . "%') OR Email = '') AND (WorkingAt LIKE ('%". $works . "%') OR WorkingAt = '') AND (LivingIn LIKE ('%". $lives . "%') OR LivingIn = '') AND (Birthday LIKE ('%". $dob . "%') OR Birthday = '') AND (StudiedAt LIKE ('%". $studied . "%') OR StudiedAt = '') AND LOWER(Content) LIKE ('%" . strtolower($content) . "%') AND OSN1.id = o1.UserId;";
      //echo $query;
      $sql = $conn->prepare($query);
      $sql->execute();
      $result = $sql->get_result();
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $instant = date_create_from_format('Y-m-d H:i:s', $row["Instant"]);
          $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $instant->format("d F Y | h:i A") . '</h2></div><div class="mdl-card__supporting-text">' . $row["Content"] . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></button></div></div>';
        }
      }  else {
        $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No posts on&nbsp;<img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></h2></div></div>';
      }
    } else {
      $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No results!</h2></div></div>';
    }
  } else {
    $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">Nothing to show!</h2></div></div>';
  }
  
  $conn->close();
  */
  echo $output;
}

?>