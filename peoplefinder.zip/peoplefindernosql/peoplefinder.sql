-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 03, 2018 at 03:13 PM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `peoplefinder`
--

-- --------------------------------------------------------

--
-- Table structure for table `osn1`
--

DROP TABLE IF EXISTS `osn1`;
CREATE TABLE IF NOT EXISTS `osn1` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(255) DEFAULT '',
  `LastName` varchar(255) DEFAULT '',
  `Email` varchar(255) DEFAULT '',
  `WorkingAt` varchar(255) DEFAULT '',
  `LivingIn` varchar(255) DEFAULT '',
  `FromPlace` varchar(255) DEFAULT '',
  `Birthday` varchar(255) DEFAULT '',
  `StudiedAt` varchar(255) DEFAULT '',
  `Link` varchar(256) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn1`
--

INSERT INTO `osn1` (`id`, `FirstName`, `LastName`, `Email`, `WorkingAt`, `LivingIn`, `FromPlace`, `Birthday`, `StudiedAt`, `Link`) VALUES
(1, 'Silas', 'Drake', 'erat.nonummy@maurissapien.ca', 'Mi Inc.', 'Varna/Vahrn', 'Grasse', '1985-11-14', 'RAIT', NULL),
(2, 'Kamal', 'Maddox', 'Donec.feugiat.metus@Etiamligulatortor.co.uk', 'Risus Donec Ltd', 'Viano', 'Sint-Kwintens-Lennik', '1951-08-05', 'FCRIT', NULL),
(3, 'Geraldine', 'Baird', 'sem.magna@penatibuset.co.uk', 'Accumsan Interdum Libero Incorporated', 'Malle', 'Maracalagonis', '1972-03-13', 'FCRIT', NULL),
(4, 'Amery', 'Cervantes', 'venenatis@purus.com', 'Lectus Pede Et Foundation', 'Paternopoli', 'Whitchurch', '2003-06-21', 'FCRIT', NULL),
(5, 'Iola', 'Glenn', 'malesuada@arcuVestibulum.co.uk', 'Nec Incorporated', 'Lalbahadur Nagar', 'Oberwart', '1992-06-08', 'TERNA', NULL),
(6, 'Madaline', 'Farrell', 'rutrum@lobortis.edu', 'Ultrices Industries', 'Pont-Saint-Martin', 'Carlisle', '1998-09-12', 'SNDT', NULL),
(7, 'Wyatt', 'Cannon', 'molestie.in.tempus@Donec.ca', 'Aliquet Foundation', 'Chillán', 'Souvret', '1956-06-27', 'PIIT', NULL),
(8, 'Axel', 'Holman', 'morbi.tristique.senectus@Aeneaneuismodmauris.com', 'Aliquam Corp.', 'Coassolo Torinese', 'Nogales', '1985-09-13', 'RAIT', NULL),
(9, 'Maryam', 'Buckley', 'nec.tempus.mauris@Praesent.com', 'Donec Institute', 'Blankenfelde-Mahlow', 'Huntley', '1954-04-09', 'RAIT', NULL),
(10, 'Uriel', 'Hess', 'tristique.senectus@id.org', 'Elementum Company', 'Passau', 'Joliet', '1960-05-18', 'FCRIT', NULL),
(11, 'Barrett', 'Houston', 'consequat@purusDuis.edu', 'Cursus Et Inc.', 'Altamura', 'Würzburg', '2004-04-03', 'SNDT', NULL),
(12, 'Lucius', 'Mcconnell', 'ac.sem.ut@elitfermentum.org', 'Natoque Penatibus Et Limited', 'Bo?lhe', 'Lummen', '1956-03-28', 'SNDT', NULL),
(13, 'Britanni', 'Brewer', 'Sed@metus.edu', 'Egestas A Scelerisque Industries', 'Gretna', 'Paranaguá', '1977-02-19', 'RAIT', NULL),
(14, 'Ezekiel', 'Hays', 'Vestibulum@tincidunttempus.com', 'Mollis Inc.', 'Sepino', 'Guntur', '1990-04-24', 'RAIT', NULL),
(15, 'Lee', 'Wyatt', 'massa.lobortis.ultrices@parturient.org', 'Nam Consequat Corp.', 'Vernole', 'Laives/Leifers', '1984-06-23', 'TERNA', NULL),
(16, 'Shaine', 'Knowles', 'nonummy.Fusce@gravidamauris.ca', 'Elit Company', 'Castel Ritaldi', 'Ottawa-Carleton', '1958-06-20', 'RAIT', NULL),
(17, 'Iona', 'Reeves', 'ante.dictum.cursus@libero.com', 'Luctus Lobortis Class Ltd', 'Bo\'ness', 'Saint-Pierre', '1974-05-03', 'RAIT', NULL),
(18, 'Naida', 'Ward', 'faucibus.orci@gravidamolestie.org', 'Et Incorporated', 'Colmar', 'New Sarepta', '1997-03-12', 'TERNA', NULL),
(19, 'Marshall', 'Morris', 'Fusce.mi@diameudolor.org', 'Erat Eget Industries', 'Dibrugarh', 'Piringen', '2007-05-14', 'TERNA', NULL),
(20, 'Anthony', 'Waters', 'vel.venenatis@ligula.ca', 'Justo Nec Industries', 'Te Puke', 'Hilo', '1992-12-15', 'TERNA', NULL),
(21, 'Jordan', 'Mcknight', 'orci.Donec@mus.org', 'Velit LLP', 'Flamierge', 'Uitkerke', '1952-08-13', 'RAIT', NULL),
(22, 'Duncan', 'Maldonado', 'luctus@pretium.net', 'Penatibus Limited', 'Hattiesburg', 'Barranca', '1962-09-05', 'ACPCOE', NULL),
(23, 'Cheryl', 'Zamora', 'Aliquam.fringilla.cursus@justoPraesent.edu', 'Cras PC', 'Forges', 'Preston', '2006-12-22', 'TERNA', NULL),
(24, 'Desiree', 'Melendez', 'Proin@urna.org', 'Gravida LLC', 'Neerharen', 'Schleswig', '1977-01-15', 'SNDT', NULL),
(25, 'Walker', 'Greene', 'Mauris@semperduilectus.edu', 'Donec Est Nunc PC', 'St. Petersburg', 'Meerle', '1969-08-11', 'TERNA', NULL),
(26, 'Katell', 'Lindsey', 'convallis.ligula@euaugue.net', 'At Augue Industries', 'Grafton', 'Gaasbeek', '2005-03-01', 'SNDT', NULL),
(27, 'Shad', 'Norton', 'ornare.lectus.ante@lacusQuisqueimperdiet.com', 'Ut Mi Corp.', 'Chaumont-Gistoux', 'Cabildo', '1985-04-09', 'SNDT', NULL),
(28, 'Emerson', 'Stevenson', 'eleifend@feugiatSed.edu', 'Nascetur Associates', 'Massa e Cozzile', 'Luttre', '1976-03-31', 'RAIT', NULL),
(29, 'Leslie', 'Lester', 'Etiam.imperdiet@pellentesqueegetdictum.ca', 'Magnis Associates', 'Raiganj', 'Langley', '1956-03-10', 'TERNA', NULL),
(30, 'Steven', 'Willis', 'tempus.eu@at.edu', 'Id Enim Curabitur Foundation', 'Houston', 'Rosciano', '2008-07-17', 'TERNA', NULL),
(31, 'Olivia', 'Atkins', 'dui.nec@euaccumsansed.org', 'Nullam Scelerisque Associates', 'Gävle', 'Khanpur', '1998-07-27', 'SNDT', NULL),
(32, 'Geoffrey', 'Weaver', 'in.lobortis.tellus@mus.co.uk', 'Ut Cursus Luctus Consulting', 'Oppido Mamertina', 'Cantalupo in Sabina', '1956-11-01', 'FCRIT', NULL),
(33, 'Justin', 'Conner', 'fringilla.porttitor.vulputate@sitametultricies.co.uk', 'Egestas Hendrerit Associates', 'Chicoutimi', 'Torquay', '1976-08-01', 'ACPCOE', NULL),
(34, 'Gloria', 'Whitaker', 'nascetur.ridiculus@elit.com', 'Nunc Est Mollis Incorporated', 'Stalowa Wola', '?negöl', '1983-04-12', 'SNDT', NULL),
(35, 'Levi', 'Donaldson', 'nibh.Donec.est@gravidamauris.org', 'Congue Foundation', 'Ancona', 'Pemberton', '1990-03-08', 'ACPCOE', NULL),
(36, 'Len', 'Sexton', 'dui.Fusce.aliquam@nislNulla.ca', 'Sit Amet Foundation', 'Bon Accord', 'Maranguape', '1957-06-12', 'PIIT', NULL),
(37, 'Talon', 'Mendez', 'Mauris.blandit.enim@enimSuspendissealiquet.com', 'Mattis Cras Foundation', 'Gagliano del Capo', 'Sint-Andries', '1957-03-04', 'FCRIT', NULL),
(38, 'Daquan', 'Reid', 'tincidunt.dui.augue@nonluctussit.ca', 'Dolor Quam Elementum Corp.', 'Compiègne', 'Caldarola', '1985-11-18', 'PIIT', NULL),
(39, 'Sarah', 'Everett', 'Donec@eteuismod.co.uk', 'Lorem Associates', 'Klemskerke', 'Algeciras', '1991-04-22', 'RAIT', NULL),
(40, 'Serina', 'Barrera', 'gravida.mauris@nullaCraseu.net', 'Cras Eget Corp.', 'Jamioulx', 'Campbeltown', '1992-04-05', 'ACPCOE', NULL),
(41, 'Rhoda', 'Greer', 'gravida.mauris.ut@fringillamilacinia.co.uk', 'Sed Incorporated', 'Parral', 'Campbelltown', '1951-06-07', 'TERNA', NULL),
(42, 'Eleanor', 'Dillard', 'ante@mattisvelitjusto.ca', 'Nisl Sem Consequat LLC', 'Pollein', 'Drachten', '2006-03-09', 'ACPCOE', NULL),
(43, 'Macon', 'Chapman', 'diam@Aeneanegetmagna.org', 'Donec Institute', 'Opgrimbie', 'Picinisco', '1974-05-16', 'FCRIT', NULL),
(44, 'Yasir', 'Gross', 'interdum.libero@Cumsociisnatoque.org', 'Lobortis Augue Scelerisque Ltd', 'Terni', 'Winchester', '1978-10-07', 'PIIT', NULL),
(45, 'Edward', 'Ruiz', 'pharetra@vel.edu', 'Erat Eget Limited', 'Millport', 'Edam', '2009-08-08', 'PIIT', NULL),
(46, 'Julian', 'Mcintosh', 'Lorem.ipsum@amet.org', 'Magna Ltd', 'Ribeirão Preto', 'Rimouski', '1987-02-02', 'RAIT', NULL),
(47, 'Kasper', 'Allison', 'auctor.Mauris@auguemalesuada.com', 'Velit In Aliquet PC', 'Bathgate', 'Luino', '1958-03-21', 'ACPCOE', NULL),
(48, 'Naida', 'Joseph', 'dictum@orci.ca', 'Quisque Inc.', 'Rutland', 'Abbeville', '1976-11-08', 'SNDT', NULL),
(49, 'Palmer', 'Mcgowan', 'fermentum.metus.Aenean@dui.com', 'In LLC', 'Clydebank', 'Orilla', '1992-08-11', 'FCRIT', NULL),
(50, 'Jade', 'Kinney', 'adipiscing@pretiumaliquetmetus.org', 'Magnis Dis Parturient Incorporated', 'Cardiff', 'Harrison Hot Springs', '1983-09-15', 'ACPCOE', NULL),
(51, 'Addison', 'Waller', 'risus@FuscefeugiatLorem.ca', 'Sed Corp.', 'Juneau', 'Saint-Eug?ne-de-Guigues', '1963-12-30', 'RAIT', NULL),
(52, 'Minerva', 'Burris', 'risus.quis.diam@Cumsociis.org', 'Malesuada Integer Company', 'Salt Lake City', 'Putre', '1955-06-23', 'SNDT', NULL),
(53, 'Leonard', 'Livingston', 'enim@dolorFuscefeugiat.co.uk', 'Aliquam Limited', 'Terlago', 'Merksplas', '1955-10-31', 'ACPCOE', NULL),
(54, 'Violet', 'Castro', 'a.malesuada.id@vehicula.ca', 'Pellentesque Habitant Morbi Institute', 'Montague', 'Schore', '1990-09-28', 'ACPCOE', NULL),
(55, 'Xander', 'Logan', 'lectus.a@vitaemauris.co.uk', 'Rhoncus Nullam Consulting', 'Chiaromonte', 'Meeuwen-Gruitrode', '1971-09-22', 'RAIT', NULL),
(56, 'Carol', 'Morris', 'habitant.morbi@dui.co.uk', 'Scelerisque Lorem Limited', 'Pabianice', 'Bolzano Vicentino', '1954-02-12', 'TERNA', NULL),
(57, 'Steel', 'Salazar', 'pede@Curabiturmassa.net', 'Accumsan Neque Foundation', 'Werbomont', 'Montelupo Fiorentino', '1995-08-31', 'FCRIT', NULL),
(58, 'Walker', 'Lopez', 'velit.Cras.lorem@hendrerit.edu', 'Sem Vitae Aliquam Foundation', 'Froidchapelle', 'Froidchapelle', '2008-12-05', 'FCRIT', NULL),
(59, 'Kirk', 'Luna', 'Sed.congue.elit@scelerisqueneque.com', 'Enim Diam Vel Corp.', 'March', 'Sagamu', '1967-10-03', 'PIIT', NULL),
(60, 'Odessa', 'York', 'blandit@Suspendissetristiqueneque.com', 'Non Justo Foundation', 'Motta Camastra', 'Minturno', '1990-01-24', 'RAIT', NULL),
(61, 'Constance', 'Calderon', 'lobortis@pedemalesuada.org', 'Arcu Curabitur Company', 'Beauvechain', 'Keiem', '2007-06-27', 'RAIT', NULL),
(62, 'Geoffrey', 'Gutierrez', 'adipiscing.lacus.Ut@dis.co.uk', 'Semper Dui Lectus Institute', 'Waren', 'Wambeek', '2005-04-26', 'FCRIT', NULL),
(63, 'Kelly', 'Fitzpatrick', 'quis@risus.org', 'Mollis Vitae Posuere LLP', 'Wellington', 'Puqueldón', '1984-11-23', 'FCRIT', NULL),
(64, 'Galvin', 'Erickson', 'tellus@enimnonnisi.edu', 'Non Arcu Foundation', 'Diegem', 'Solre-Saint-G?ry', '1964-09-20', 'SNDT', NULL),
(65, 'Bruno', 'Hamilton', 'sapien.Aenean.massa@blanditmattis.co.uk', 'Non Nisi Aenean Associates', 'Huntsville', 'Renfrew', '1955-10-25', 'ACPCOE', NULL),
(66, 'Brandon', 'Decker', 'vel@condimentumDonecat.org', 'Faucibus Leo In Incorporated', 'Isle-aux-Coudres', 'Lossiemouth', '1953-11-14', 'ACPCOE', NULL),
(67, 'Talon', 'Strickland', 'velit@facilisislorem.ca', 'Aliquet Consulting', 'Remscheid', 'St. John\'s', '1962-11-03', 'SNDT', NULL),
(68, 'Ivor', 'Pierce', 'dictum@sitametornare.com', 'Cras Industries', 'Opprebais', 'Francavilla in Sinni', '1969-02-08', 'SNDT', NULL),
(69, 'Philip', 'Macias', 'pharetra.ut@etmagna.net', 'Lorem Associates', 'Uitkerke', 'Ospedaletto Lodigiano', '1958-03-26', 'TERNA', NULL),
(70, 'Zachery', 'Ross', 'nec@enimmi.net', 'Egestas Urna Foundation', 'Jamnagar', 'Castel del Giudice', '1995-12-21', 'PIIT', NULL),
(71, 'Sloane', 'Shepard', 'convallis.dolor@Phasellus.edu', 'Maecenas Foundation', 'Wuppertal', 'Cinco Esquinas', '1996-06-09', 'TERNA', NULL),
(72, 'Colt', 'Adams', 'blandit.mattis@odio.ca', 'In Faucibus Orci Ltd', 'Fortune', 'Carleton', '1967-02-22', 'PIIT', NULL),
(73, 'Portia', 'Mcmahon', 'Suspendisse.dui@pede.co.uk', 'Tincidunt Congue Turpis PC', 'Largs', 'Harrisburg', '1988-12-10', 'RAIT', NULL),
(74, 'William', 'Wade', 'ac.ipsum.Phasellus@eleifendegestasSed.org', 'Pharetra Ut Company', 'Bhiwandi', 'Nimy', '2008-12-12', 'FCRIT', NULL),
(75, 'Gannon', 'Jacobs', 'eros@sociis.edu', 'Netus Et PC', 'Swindon', 'Delta', '1963-10-04', 'ACPCOE', NULL),
(76, 'Abraham', 'Dawson', 'penatibus@ultrices.net', 'Enim Industries', 'Steyr', 'Bear', '1982-07-10', 'PIIT', NULL),
(77, 'Brooke', 'Frazier', 'odio@erosnectellus.com', 'Proin Non Massa Consulting', 'Spokane', 'Camrose', '1952-12-27', 'RAIT', NULL),
(78, 'Quinn', 'Curtis', 'erat.Sed.nunc@sitamet.com', 'Eu Augue Porttitor Industries', 'San Benedetto del Tronto', 'Grafton', '1974-06-16', 'FCRIT', NULL),
(79, 'Hilary', 'Booth', 'Donec@ametornarelectus.ca', 'Ac Feugiat Non Industries', 'Worcester', 'Ambresin', '1979-07-24', 'PIIT', NULL),
(80, 'Madeline', 'Allen', 'est.Nunc.ullamcorper@vestibulum.com', 'Convallis Ante Inc.', 'Palagianello', 'Châlons-en-Champagne', '1957-11-21', 'RAIT', NULL),
(81, 'Madonna', 'Mcdonald', 'risus@orci.net', 'Lacus Cras Industries', 'Vienna', 'Heule', '1964-08-02', 'PIIT', NULL),
(82, 'Dawn', 'Taylor', 'ultricies@Maurismolestie.co.uk', 'Cursus Integer Associates', 'Wardha', 'Dabgram', '1976-09-02', 'RAIT', NULL),
(83, 'Quincy', 'Baker', 'nunc.id.enim@eget.net', 'Nunc In At Incorporated', 'Wodonga', 'Hofstade', '1957-01-15', 'TERNA', NULL),
(84, 'Brandon', 'Martin', 'mi@bibendumDonecfelis.com', 'Aliquet Magna A Company', 'Uyo', 'Missoula', '2000-03-24', 'ACPCOE', NULL),
(85, 'Brett', 'Noel', 'vehicula.aliquet.libero@leo.org', 'Mi Company', 'Rocca d\'Arazzo', 'Charny', '1958-07-24', 'FCRIT', NULL),
(86, 'Evan', 'Hart', 'volutpat.Nulla.dignissim@MorbimetusVivamus.net', 'Purus Accumsan Interdum LLP', 'Pozo Almonte', 'Wandsworth', '1969-02-10', 'SNDT', NULL),
(87, 'Lucas', 'Dodson', 'malesuada@commodohendrerit.net', 'At Velit Corporation', 'Patarrá', 'Maglie', '1951-06-12', 'ACPCOE', NULL),
(88, 'Neville', 'Campbell', 'urna.suscipit.nonummy@miloremvehicula.co.uk', 'Tristique Pellentesque Tellus Incorporated', 'Thunder Bay', 'Pugwash', '1954-11-18', 'RAIT', NULL),
(89, 'Buckminster', 'Alford', 'eu.erat@temporaugueac.edu', 'Vivamus Rhoncus Inc.', 'Edmonton', 'Rugby', '1973-07-14', 'PIIT', NULL),
(90, 'Porter', 'Lucas', 'mollis.dui@aliquet.org', 'Tincidunt Pede Ac Industries', 'Olathe', 'Lleida', '1996-08-17', 'SNDT', NULL),
(91, 'Ella', 'Cleveland', 'nostra@dignissim.com', 'Ac Mattis Velit Foundation', 'Lewiston', 'Cicagna', '1950-05-08', 'RAIT', NULL),
(92, 'Kasper', 'Baird', 'arcu@Cumsociisnatoque.com', 'Phasellus Dolor Elit Inc.', 'Golspie', 'Stirling', '1970-04-01', 'PIIT', NULL),
(93, 'Alea', 'Arnold', 'ipsum.Curabitur.consequat@blandit.co.uk', 'Nec Enim Limited', 'Price', 'Drogenbos', '1997-06-08', 'FCRIT', NULL),
(94, 'Yolanda', 'Daniels', 'at.iaculis.quis@lacus.edu', 'Risus Varius Orci PC', 'Berg', 'Salamanca', '1962-10-05', 'SNDT', NULL),
(95, 'Chloe', 'Stewart', 'est.tempor.bibendum@Nuncuterat.org', 'Vel Est Tempor Institute', 'Angoulême', 'Itterbeek', '1981-04-11', 'TERNA', NULL),
(96, 'Kadeem', 'Holman', 'odio.vel.est@pretiumneque.edu', 'Nunc Id Enim Incorporated', 'Itegem', 'Carpignano Salentino', '1953-01-10', 'SNDT', NULL),
(97, 'Hedley', 'Cole', 'neque@fringillaporttitor.com', 'Mollis Inc.', 'San Pablo', 'Baunatal', '1951-01-13', 'PIIT', NULL),
(98, 'Caldwell', 'Mcgowan', 'tortor.at.risus@lobortis.com', 'Id Enim Inc.', 'Millport', 'Cabras', '1974-09-07', 'RAIT', NULL),
(99, 'Zephania', 'Swanson', 'non.bibendum@risusMorbi.org', 'Consectetuer Associates', 'Minneapolis', 'Lodine', '1951-06-22', 'ACPCOE', NULL),
(100, 'Kenneth', 'Humphrey', '', '', 'Sankt Wendel', 'Ragnies', '1963-06-07', 'SNDT', NULL),
(101, 'Kenneth', 'Humphrey', 'abc@xyz.com', 'Facebook', '', 'Gonda', '1996-08-08', 'RAIT', ''),
(102, 'Nimisha', 'Gopalakrishnan', 'nimishaaa.g@gmail.com', '', 'Mumbai', 'Bahrain', '1996-08-08', 'RAIT', 'https://www.facebook.com/nimisha.gopalakrishnan'),
(103, 'Divya', 'Reddy', 'divya.duvvuru@gmail.com', '', 'Mumbai', 'Hyderabad', '1996-12-23', 'RAIT', 'https://www.facebook.com/divya.reddy.16503'),
(104, 'Nimisha', 'Gopalakrishnan', 'nim.gopal@gmail.com', '', 'Kerala', 'Kerala', '1990-10-02', 'VIT', 'https://www.facebook.com/nim.gopal'),
(105, 'Ajinkya', 'Pawar', 'aju37pawar@gmail.com', 'ATOS', 'Mumbai', 'Mumbai', '1997-01-05', 'RAIT', 'https://www.facebook.com/ajinkya.pawar.330'),
(107, 'Aishwarya', 'Shetty', 'aishwarya.shetty86@gmail.com', 'TCS', 'Mumbai', 'Karnataka', '1996-04-26', 'RAIT', 'https://www.facebook.com/aishwaryashetty86'),
(108, 'Nilesh', 'Prajapati', 'turboblaze@gmail.com', 'TCS', 'Mumbai', 'Mumbai', '', 'RAIT', 'https://www.facebook.com/nileshp'),
(109, 'Rhea', 'Pradhan', 'rhea.pradhan@gmail.com', '', 'Mumbai', 'Orissa', '1996-04-08', 'RAIT', 'https://www.facebook.com/rhea.pradhan.14'),
(110, 'Aman', 'Banka', 'aman.banka@gmail.com', '', 'Mumbai', 'Rajasthan', '1997-01-27', 'RAIT', 'https://www.facebook.com/aman.b100'),
(111, 'Vivek', 'Prajapati', 'vivek6522@outlook.com', '', 'Amsterdam', 'Mumbai', '', 'FCRIT', 'https://www.facebook.com/vivek_prajapati');

-- --------------------------------------------------------

--
-- Table structure for table `osn1_content`
--

DROP TABLE IF EXISTS `osn1_content`;
CREATE TABLE IF NOT EXISTS `osn1_content` (
  `ContentId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) NOT NULL,
  `Content` varchar(10240) NOT NULL,
  `Instant` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ContentId`),
  KEY `UserId` (`UserId`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn1_content`
--

INSERT INTO `osn1_content` (`ContentId`, `UserId`, `Content`, `Instant`) VALUES
(1, 102, 'This is my first post on Facebook. Feeling excited.\r\nPosted from Bahrain.', '2018-03-01 08:39:01'),
(2, 102, 'This is my second post on Facebook. Not very boring.\r\nPosted from Mumbai.', '2018-03-03 08:39:31'),
(3, 104, 'Had fun in college today. VIT rocks.', '2018-03-03 18:20:25'),
(4, 104, 'Hanging out with a friend today.', '2018-03-03 18:20:25'),
(5, 102, 'I got a new job.', '2018-03-03 18:43:24');

-- --------------------------------------------------------

--
-- Table structure for table `osn2`
--

DROP TABLE IF EXISTS `osn2`;
CREATE TABLE IF NOT EXISTS `osn2` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(255) DEFAULT '',
  `LastName` varchar(255) DEFAULT '',
  `Email` varchar(255) DEFAULT '',
  `WorkingAt` varchar(255) DEFAULT '',
  `LivingIn` varchar(255) DEFAULT '',
  `Birthday` varchar(255) DEFAULT '',
  `StudiedAt` varchar(255) DEFAULT '',
  `Link` varchar(256) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn2`
--

INSERT INTO `osn2` (`id`, `FirstName`, `LastName`, `Email`, `WorkingAt`, `LivingIn`, `Birthday`, `StudiedAt`, `Link`) VALUES
(1, 'Silas', 'Drake', 'erat.nonummy@maurissapien.ca', 'Mi Inc.', 'Varna/Vahrn', '1985-11-14', 'RAIT', NULL),
(2, 'Kamal', 'Maddox', 'Donec.feugiat.metus@Etiamligulatortor.co.uk', 'Risus Donec Ltd', 'Viano', '1951-08-05', 'FCRIT', NULL),
(3, 'Geraldine', 'Baird', 'sem.magna@penatibuset.co.uk', 'Accumsan Interdum Libero Incorporated', 'Malle', '1972-03-13', 'FCRIT', NULL),
(4, 'Amery', 'Cervantes', 'venenatis@purus.com', 'Lectus Pede Et Foundation', 'Paternopoli', '2003-06-21', 'FCRIT', NULL),
(5, 'Iola', 'Glenn', 'malesuada@arcuVestibulum.co.uk', 'Nec Incorporated', 'Lalbahadur Nagar', '1992-06-08', 'TERNA', NULL),
(6, 'Madaline', 'Farrell', 'rutrum@lobortis.edu', 'Ultrices Industries', 'Pont-Saint-Martin', '1998-09-12', 'SNDT', NULL),
(7, 'Wyatt', 'Cannon', 'molestie.in.tempus@Donec.ca', 'Aliquet Foundation', 'Chillán', '1956-06-27', 'PIIT', NULL),
(8, 'Axel', 'Holman', 'morbi.tristique.senectus@Aeneaneuismodmauris.com', 'Aliquam Corp.', 'Coassolo Torinese', '1985-09-13', 'RAIT', NULL),
(9, 'Maryam', 'Buckley', 'nec.tempus.mauris@Praesent.com', 'Donec Institute', 'Blankenfelde-Mahlow', '1954-04-09', 'RAIT', NULL),
(10, 'Uriel', 'Hess', 'tristique.senectus@id.org', 'Elementum Company', 'Passau', '1960-05-18', 'FCRIT', NULL),
(11, 'Barrett', 'Houston', 'consequat@purusDuis.edu', 'Cursus Et Inc.', 'Altamura', '2004-04-03', 'SNDT', NULL),
(12, 'Lucius', 'Mcconnell', 'ac.sem.ut@elitfermentum.org', 'Natoque Penatibus Et Limited', 'Bo?lhe', '1956-03-28', 'SNDT', NULL),
(13, 'Britanni', 'Brewer', 'Sed@metus.edu', 'Egestas A Scelerisque Industries', 'Gretna', '1977-02-19', 'RAIT', NULL),
(14, 'Ezekiel', 'Hays', 'Vestibulum@tincidunttempus.com', 'Mollis Inc.', 'Sepino', '1990-04-24', 'RAIT', NULL),
(15, 'Lee', 'Wyatt', 'massa.lobortis.ultrices@parturient.org', 'Nam Consequat Corp.', 'Vernole', '1984-06-23', 'TERNA', NULL),
(16, 'Shaine', 'Knowles', 'nonummy.Fusce@gravidamauris.ca', 'Elit Company', 'Castel Ritaldi', '1958-06-20', 'RAIT', NULL),
(17, 'Iona', 'Reeves', 'ante.dictum.cursus@libero.com', 'Luctus Lobortis Class Ltd', 'Bo\'ness', '1974-05-03', 'RAIT', NULL),
(18, 'Naida', 'Ward', 'faucibus.orci@gravidamolestie.org', 'Et Incorporated', 'Colmar', '1997-03-12', 'TERNA', NULL),
(19, 'Marshall', 'Morris', 'Fusce.mi@diameudolor.org', 'Erat Eget Industries', 'Dibrugarh', '2007-05-14', 'TERNA', NULL),
(20, 'Anthony', 'Waters', 'vel.venenatis@ligula.ca', 'Justo Nec Industries', 'Te Puke', '1992-12-15', 'TERNA', NULL),
(21, 'Jordan', 'Mcknight', 'orci.Donec@mus.org', 'Velit LLP', 'Flamierge', '1952-08-13', 'RAIT', NULL),
(22, 'Duncan', 'Maldonado', 'luctus@pretium.net', 'Penatibus Limited', 'Hattiesburg', '1962-09-05', 'ACPCOE', NULL),
(23, 'Cheryl', 'Zamora', 'Aliquam.fringilla.cursus@justoPraesent.edu', 'Cras PC', 'Forges', '2006-12-22', 'TERNA', NULL),
(24, 'Desiree', 'Melendez', 'Proin@urna.org', 'Gravida LLC', 'Neerharen', '1977-01-15', 'SNDT', NULL),
(25, 'Walker', 'Greene', 'Mauris@semperduilectus.edu', 'Donec Est Nunc PC', 'St. Petersburg', '1969-08-11', 'TERNA', NULL),
(26, 'Katell', 'Lindsey', 'convallis.ligula@euaugue.net', 'At Augue Industries', 'Grafton', '2005-03-01', 'SNDT', NULL),
(27, 'Shad', 'Norton', 'ornare.lectus.ante@lacusQuisqueimperdiet.com', 'Ut Mi Corp.', 'Chaumont-Gistoux', '1985-04-09', 'SNDT', NULL),
(28, 'Emerson', 'Stevenson', 'eleifend@feugiatSed.edu', 'Nascetur Associates', 'Massa e Cozzile', '1976-03-31', 'RAIT', NULL),
(29, 'Leslie', 'Lester', 'Etiam.imperdiet@pellentesqueegetdictum.ca', 'Magnis Associates', 'Raiganj', '1956-03-10', 'TERNA', NULL),
(30, 'Steven', 'Willis', 'tempus.eu@at.edu', 'Id Enim Curabitur Foundation', 'Houston', '2008-07-17', 'TERNA', NULL),
(31, 'Olivia', 'Atkins', 'dui.nec@euaccumsansed.org', 'Nullam Scelerisque Associates', 'Gävle', '1998-07-27', 'SNDT', NULL),
(32, 'Geoffrey', 'Weaver', 'in.lobortis.tellus@mus.co.uk', 'Ut Cursus Luctus Consulting', 'Oppido Mamertina', '1956-11-01', 'FCRIT', NULL),
(33, 'Justin', 'Conner', 'fringilla.porttitor.vulputate@sitametultricies.co.uk', 'Egestas Hendrerit Associates', 'Chicoutimi', '1976-08-01', 'ACPCOE', NULL),
(34, 'Gloria', 'Whitaker', 'nascetur.ridiculus@elit.com', 'Nunc Est Mollis Incorporated', 'Stalowa Wola', '1983-04-12', 'SNDT', NULL),
(35, 'Levi', 'Donaldson', 'nibh.Donec.est@gravidamauris.org', 'Congue Foundation', 'Ancona', '1990-03-08', 'ACPCOE', NULL),
(36, 'Len', 'Sexton', 'dui.Fusce.aliquam@nislNulla.ca', 'Sit Amet Foundation', 'Bon Accord', '1957-06-12', 'PIIT', NULL),
(37, 'Talon', 'Mendez', 'Mauris.blandit.enim@enimSuspendissealiquet.com', 'Mattis Cras Foundation', 'Gagliano del Capo', '1957-03-04', 'FCRIT', NULL),
(38, 'Daquan', 'Reid', 'tincidunt.dui.augue@nonluctussit.ca', 'Dolor Quam Elementum Corp.', 'Compiègne', '1985-11-18', 'PIIT', NULL),
(39, 'Sarah', 'Everett', 'Donec@eteuismod.co.uk', 'Lorem Associates', 'Klemskerke', '1991-04-22', 'RAIT', NULL),
(40, 'Serina', 'Barrera', 'gravida.mauris@nullaCraseu.net', 'Cras Eget Corp.', 'Jamioulx', '1992-04-05', 'ACPCOE', NULL),
(41, 'Rhoda', 'Greer', 'gravida.mauris.ut@fringillamilacinia.co.uk', 'Sed Incorporated', 'Parral', '1951-06-07', 'TERNA', NULL),
(42, 'Eleanor', 'Dillard', 'ante@mattisvelitjusto.ca', 'Nisl Sem Consequat LLC', 'Pollein', '2006-03-09', 'ACPCOE', NULL),
(43, 'Macon', 'Chapman', 'diam@Aeneanegetmagna.org', 'Donec Institute', 'Opgrimbie', '1974-05-16', 'FCRIT', NULL),
(44, 'Yasir', 'Gross', 'interdum.libero@Cumsociisnatoque.org', 'Lobortis Augue Scelerisque Ltd', 'Terni', '1978-10-07', 'PIIT', NULL),
(45, 'Edward', 'Ruiz', 'pharetra@vel.edu', 'Erat Eget Limited', 'Millport', '2009-08-08', 'PIIT', NULL),
(46, 'Julian', 'Mcintosh', 'Lorem.ipsum@amet.org', 'Magna Ltd', 'Ribeirão Preto', '1987-02-02', 'RAIT', NULL),
(47, 'Kasper', 'Allison', 'auctor.Mauris@auguemalesuada.com', 'Velit In Aliquet PC', 'Bathgate', '1958-03-21', 'ACPCOE', NULL),
(48, 'Naida', 'Joseph', 'dictum@orci.ca', 'Quisque Inc.', 'Rutland', '1976-11-08', 'SNDT', NULL),
(49, 'Palmer', 'Mcgowan', 'fermentum.metus.Aenean@dui.com', 'In LLC', 'Clydebank', '1992-08-11', 'FCRIT', NULL),
(50, 'Jade', 'Kinney', 'adipiscing@pretiumaliquetmetus.org', 'Magnis Dis Parturient Incorporated', 'Cardiff', '1983-09-15', 'ACPCOE', NULL),
(51, 'Addison', 'Waller', 'risus@FuscefeugiatLorem.ca', 'Sed Corp.', 'Juneau', '1963-12-30', 'RAIT', NULL),
(52, 'Minerva', 'Burris', 'risus.quis.diam@Cumsociis.org', 'Malesuada Integer Company', 'Salt Lake City', '1955-06-23', 'SNDT', NULL),
(53, 'Leonard', 'Livingston', 'enim@dolorFuscefeugiat.co.uk', 'Aliquam Limited', 'Terlago', '1955-10-31', 'ACPCOE', NULL),
(54, 'Violet', 'Castro', 'a.malesuada.id@vehicula.ca', 'Pellentesque Habitant Morbi Institute', 'Montague', '1990-09-28', 'ACPCOE', NULL),
(55, 'Xander', 'Logan', 'lectus.a@vitaemauris.co.uk', 'Rhoncus Nullam Consulting', 'Chiaromonte', '1971-09-22', 'RAIT', NULL),
(56, 'Carol', 'Morris', 'habitant.morbi@dui.co.uk', 'Scelerisque Lorem Limited', 'Pabianice', '1954-02-12', 'TERNA', NULL),
(57, 'Steel', 'Salazar', 'pede@Curabiturmassa.net', 'Accumsan Neque Foundation', 'Werbomont', '1995-08-31', 'FCRIT', NULL),
(58, 'Walker', 'Lopez', 'velit.Cras.lorem@hendrerit.edu', 'Sem Vitae Aliquam Foundation', 'Froidchapelle', '2008-12-05', 'FCRIT', NULL),
(59, 'Kirk', 'Luna', 'Sed.congue.elit@scelerisqueneque.com', 'Enim Diam Vel Corp.', 'March', '1967-10-03', 'PIIT', NULL),
(60, 'Odessa', 'York', 'blandit@Suspendissetristiqueneque.com', 'Non Justo Foundation', 'Motta Camastra', '1990-01-24', 'RAIT', NULL),
(61, 'Constance', 'Calderon', 'lobortis@pedemalesuada.org', 'Arcu Curabitur Company', 'Beauvechain', '2007-06-27', 'RAIT', NULL),
(62, 'Geoffrey', 'Gutierrez', 'adipiscing.lacus.Ut@dis.co.uk', 'Semper Dui Lectus Institute', 'Waren', '2005-04-26', 'FCRIT', NULL),
(63, 'Kelly', 'Fitzpatrick', 'quis@risus.org', 'Mollis Vitae Posuere LLP', 'Wellington', '1984-11-23', 'FCRIT', NULL),
(64, 'Galvin', 'Erickson', 'tellus@enimnonnisi.edu', 'Non Arcu Foundation', 'Diegem', '1964-09-20', 'SNDT', NULL),
(65, 'Bruno', 'Hamilton', 'sapien.Aenean.massa@blanditmattis.co.uk', 'Non Nisi Aenean Associates', 'Huntsville', '1955-10-25', 'ACPCOE', NULL),
(66, 'Brandon', 'Decker', 'vel@condimentumDonecat.org', 'Faucibus Leo In Incorporated', 'Isle-aux-Coudres', '1953-11-14', 'ACPCOE', NULL),
(67, 'Talon', 'Strickland', 'velit@facilisislorem.ca', 'Aliquet Consulting', 'Remscheid', '1962-11-03', 'SNDT', NULL),
(68, 'Ivor', 'Pierce', 'dictum@sitametornare.com', 'Cras Industries', 'Opprebais', '1969-02-08', 'SNDT', NULL),
(69, 'Philip', 'Macias', 'pharetra.ut@etmagna.net', 'Lorem Associates', 'Uitkerke', '1958-03-26', 'TERNA', NULL),
(70, 'Zachery', 'Ross', 'nec@enimmi.net', 'Egestas Urna Foundation', 'Jamnagar', '1995-12-21', 'PIIT', NULL),
(71, 'Sloane', 'Shepard', 'convallis.dolor@Phasellus.edu', 'Maecenas Foundation', 'Wuppertal', '1996-06-09', 'TERNA', NULL),
(72, 'Colt', 'Adams', 'blandit.mattis@odio.ca', 'In Faucibus Orci Ltd', 'Fortune', '1967-02-22', 'PIIT', NULL),
(73, 'Portia', 'Mcmahon', 'Suspendisse.dui@pede.co.uk', 'Tincidunt Congue Turpis PC', 'Largs', '1988-12-10', 'RAIT', NULL),
(74, 'William', 'Wade', 'ac.ipsum.Phasellus@eleifendegestasSed.org', 'Pharetra Ut Company', 'Bhiwandi', '2008-12-12', 'FCRIT', NULL),
(75, 'Gannon', 'Jacobs', 'eros@sociis.edu', 'Netus Et PC', 'Swindon', '1963-10-04', 'ACPCOE', NULL),
(76, 'Abraham', 'Dawson', 'penatibus@ultrices.net', 'Enim Industries', 'Steyr', '1982-07-10', 'PIIT', NULL),
(77, 'Brooke', 'Frazier', 'odio@erosnectellus.com', 'Proin Non Massa Consulting', 'Spokane', '1952-12-27', 'RAIT', NULL),
(78, 'Quinn', 'Curtis', 'erat.Sed.nunc@sitamet.com', 'Eu Augue Porttitor Industries', 'San Benedetto del Tronto', '1974-06-16', 'FCRIT', NULL),
(79, 'Hilary', 'Booth', 'Donec@ametornarelectus.ca', 'Ac Feugiat Non Industries', 'Worcester', '1979-07-24', 'PIIT', NULL),
(80, 'Madeline', 'Allen', 'est.Nunc.ullamcorper@vestibulum.com', 'Convallis Ante Inc.', 'Palagianello', '1957-11-21', 'RAIT', NULL),
(81, 'Madonna', 'Mcdonald', 'risus@orci.net', 'Lacus Cras Industries', 'Vienna', '1964-08-02', 'PIIT', NULL),
(82, 'Dawn', 'Taylor', 'ultricies@Maurismolestie.co.uk', 'Cursus Integer Associates', 'Wardha', '1976-09-02', 'RAIT', NULL),
(83, 'Quincy', 'Baker', 'nunc.id.enim@eget.net', 'Nunc In At Incorporated', 'Wodonga', '1957-01-15', 'TERNA', NULL),
(84, 'Brandon', 'Martin', 'mi@bibendumDonecfelis.com', 'Aliquet Magna A Company', 'Uyo', '2000-03-24', 'ACPCOE', NULL),
(85, 'Brett', 'Noel', 'vehicula.aliquet.libero@leo.org', 'Mi Company', 'Rocca d\'Arazzo', '1958-07-24', 'FCRIT', NULL),
(86, 'Evan', 'Hart', 'volutpat.Nulla.dignissim@MorbimetusVivamus.net', 'Purus Accumsan Interdum LLP', 'Pozo Almonte', '1969-02-10', 'SNDT', NULL),
(87, 'Lucas', 'Dodson', 'malesuada@commodohendrerit.net', 'At Velit Corporation', 'Patarrá', '1951-06-12', 'ACPCOE', NULL),
(88, 'Neville', 'Campbell', 'urna.suscipit.nonummy@miloremvehicula.co.uk', 'Tristique Pellentesque Tellus Incorporated', 'Thunder Bay', '1954-11-18', 'RAIT', NULL),
(89, 'Buckminster', 'Alford', 'eu.erat@temporaugueac.edu', 'Vivamus Rhoncus Inc.', 'Edmonton', '1973-07-14', 'PIIT', NULL),
(90, 'Porter', 'Lucas', 'mollis.dui@aliquet.org', 'Tincidunt Pede Ac Industries', 'Olathe', '1996-08-17', 'SNDT', NULL),
(91, 'Ella', 'Cleveland', 'nostra@dignissim.com', 'Ac Mattis Velit Foundation', 'Lewiston', '1950-05-08', 'RAIT', NULL),
(92, 'Kasper', 'Baird', 'arcu@Cumsociisnatoque.com', 'Phasellus Dolor Elit Inc.', 'Golspie', '1970-04-01', 'PIIT', NULL),
(93, 'Alea', 'Arnold', 'ipsum.Curabitur.consequat@blandit.co.uk', 'Nec Enim Limited', 'Price', '1997-06-08', 'FCRIT', NULL),
(94, 'Yolanda', 'Daniels', 'at.iaculis.quis@lacus.edu', 'Risus Varius Orci PC', 'Berg', '1962-10-05', 'SNDT', NULL),
(95, 'Chloe', 'Stewart', 'est.tempor.bibendum@Nuncuterat.org', 'Vel Est Tempor Institute', 'Angoulême', '1981-04-11', 'TERNA', NULL),
(96, 'Kadeem', 'Holman', 'odio.vel.est@pretiumneque.edu', 'Nunc Id Enim Incorporated', 'Itegem', '1953-01-10', 'SNDT', NULL),
(97, 'Hedley', 'Cole', 'neque@fringillaporttitor.com', 'Mollis Inc.', 'San Pablo', '1951-01-13', 'PIIT', NULL),
(98, 'Caldwell', 'Mcgowan', 'tortor.at.risus@lobortis.com', 'Id Enim Inc.', 'Millport', '1974-09-07', 'RAIT', NULL),
(99, 'Zephania', 'Swanson', 'non.bibendum@risusMorbi.org', 'Consectetuer Associates', 'Minneapolis', '1951-06-22', 'ACPCOE', NULL),
(100, 'Kenneth', 'Humphrey', 'imperdiet@lacusAliquam.net', 'Et Magna Praesent Incorporated', 'Sankt Wendel', '1963-06-07', 'SNDT', NULL),
(101, 'Kenneth', 'Humphrey', 'abc@xyz.com', 'Facebook', 'Mumbai', '1996-08-08', 'RAIT', ''),
(102, 'Nimisha', 'Gopalakrishnan', 'nimishaaa.g@gmail.com', 'TCS', 'Mumbai', '', 'RAIT', 'https://www.linkedin.com/in/nimisha-gopalakrishnan/'),
(103, 'Divya', 'Reddy', 'divya.duvvuru@gmail.com', 'ATOS', '', '1996-12-23', 'RAIT', 'https://www.linkedin.com/in/divya-reddy-b526a282/'),
(104, 'Nimisha', 'Gopalakrishnan', 'nim.gopal@gmail.com', '', 'Kerala', '', 'VIT', 'https://www.linkedin.com/nim.gopal'),
(105, 'Ajinkya', 'Pawar', 'aju37pawar@gmail.com', 'ATOS', 'Mumbai', '1997-01-05', 'RAIT', 'https://www.linkedin.com/in/ajinkya-pawar/'),
(106, 'Aishwarya', 'Shetty', 'aishwarya.shetty86@gmail.com', 'TCS', 'Mumbai', '1996-04-26', 'RAIT', 'https://www.linkedin.com/in/aishwarya-shetty-67b79098/'),
(107, 'Nilesh', 'Prajapati', 'turboblaze@gmail.com', 'TCS', 'Mumbai', '', 'RAIT', 'https://www.linkedin.com/in/nilesh-prajapati/'),
(108, 'Rhea', 'Pradhan', 'rhea.pradhan@gmail.com', '', 'Mumbai', '1996-08-04', 'RAIT', 'https://www.linkedin.com/in/rhea-pradhan-58614513a/'),
(109, 'Aman', 'Banka', 'aman.banka@gmail.com', 'Techdroid.in', 'Mumbai', '1997-01-27', 'RAIT', 'https://www.linkedin.com/in/amanbanka/'),
(110, 'Vivek', 'Prajapati', 'vivek6522@outlook.com', 'ABN AMRO', 'Amsterdam', '', 'FCRIT', 'https://www.linkedin.com/vivek-prajapati');

-- --------------------------------------------------------

--
-- Table structure for table `osn2_content`
--

DROP TABLE IF EXISTS `osn2_content`;
CREATE TABLE IF NOT EXISTS `osn2_content` (
  `ContentId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) NOT NULL,
  `Content` varchar(10240) NOT NULL,
  `Instant` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ContentId`),
  KEY `UserId` (`UserId`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osn2_content`
--

INSERT INTO `osn2_content` (`ContentId`, `UserId`, `Content`, `Instant`) VALUES
(1, 102, 'This is my first professional post on LinkedIn. I still ain\'t placed.\r\nPosted from Bahrain.', '2018-03-01 08:40:44'),
(2, 102, 'I\'m happy to announce that I\'m now placed in TCS. Hooray!\r\nPosted from Mumbai.', '2018-03-03 08:40:44'),
(3, 104, 'VIT\'s fest today.', '2018-03-03 18:21:57'),
(4, 104, 'Hanging out in my office canteen.', '2018-03-03 18:21:57'),
(5, 102, 'I got a new job!', '2018-03-03 18:43:40');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
