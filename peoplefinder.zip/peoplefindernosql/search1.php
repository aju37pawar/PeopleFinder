<?php

require_once("dbconnect.php");

$fname = strtolower($_POST["fname"]);
$lname = strtolower($_POST["lname"]);
$email = strtolower($_POST["email"]);
$works = strtolower($_POST["works"]);
$lives = strtolower($_POST["lives"]);
$dob = $_POST["dob"];
$studied = strtolower($_POST["studied"]);

$ar1 = array();
$regexblank1 = new MongoDB\BSON\Regex("");
if ($fname) {
  $regex31 = new MongoDB\BSON\Regex($fname, "i");
  array_push($ar1, ["fname" => $regex31]);
}
if ($lname) {
  $regex41 = new MongoDB\BSON\Regex($lname, "i");
  array_push($ar1, ["lname" => $regex41]);
}
if ($email) {
  $regex51 = new MongoDB\BSON\Regex($email, "i");
  array_push($ar1, ["email" => $regex51]);
}
if ($works) {
  $regex61 = new MongoDB\BSON\Regex($works, "i");
  array_push($ar1, ["works" => $regex61]);
}
if ($lives) {
  $regex71 = new MongoDB\BSON\Regex($lives, "i");
  array_push($ar1, ["lives" => $regex71]);
}
if ($dob) {
  $regex81 = new MongoDB\BSON\Regex($dob, "i");
  array_push($ar1, ["dob" => $regex81]);
}
if ($studied) {
  $regex91 = new MongoDB\BSON\Regex($studied, "i");
  array_push($ar1, ["studied" => $regex91]);
}
$filter = [
  '$and' => $ar1/*[
    ['fname' => $regex3],
    ['lname' => $regex4],
    ['email' => $regex5],
    ['works' => $regex6],
    ['lives' => $regex7],
    ['dob' => $regex8],
    ['studied' => $regex9]
  ]*/
];
$options = [];

$output = "";
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $m->executeQuery('peoplefinder.osn1', $query);
$ofound = false;
foreach ($cursor as $document) {
  $ofound = true;
  //echo $document->fname;
  $count = 0;
  $fname_match = false;
  $lname_match = false;
  $email_match = false;
  $works_match = false;
  $lives_match = false;
  $dob_match = false;
  $studied_match = false;
  
  if ($fname == strtolower($document->fname)) {
    $count++;
    $fname_match = true;
  }
  
  if ($lname == strtolower($document->lname)) {
    $count++;
    $lname_match = true;
  }
  
  if ($email == strtolower($document->email)) {
    $count++;
    $email_match = true;
  }
  
  if ($document->works && $works == strtolower($document->works)) {
    $count++;
    $works_match = true;
  }
  
  if ($document->lives && $lives == strtolower($document->lives)) {
    $count++;
    $lives_match = true;
  }
  
  if ($dob == $document->dob) {
    $count++;
    $dob_match = true;
  }
  
  if ($studied == strtolower($document->studied)) {
    $count++;
    $studied_match = true;
  }
  
  //$output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $cursor[0]->fname . " " . $cursor[0]->lname . '</h2></div><div class="mdl-card__supporting-text">Email: ' . $cursor[0]->email . '<br />Working at: ' . $cursor[0]->works . '<br />LivingIn: ' . $cursor[0]->lives . '<br />Birthday: ' . $cursor[0]->dob . '<br />Studied at: ' . $cursor[0]->studied . '<br />Link: <a href="' . $cursor[0]->link . '">' . $cursor[0]->link . '</a></div><div class="mdl-card__actions"><a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect" href="content.php?id2=' . $document->id . '">Show content</a></div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="linkedin-logo.png" class="osn-logo" /></button></div></div>';
  
  $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $document->fname . " " . $document->lname . '</h2></div><div class="mdl-card__supporting-text">' . (($document->email == "") ? "" : 'Email: ' . $document->email . '<br />') . (($document->works == "") ? "" : 'Working at: ' . $document->works . '<br />') . (($document->lives == "") ? "" : 'Living in: ' . $document->lives . '<br />') . (($document->dob == "") ? "" : 'Birthday: ' . $document->dob . '<br />') . (($document->studied == "") ? "" : 'Studied at: ' . $document->studied . '<br />') . (($document->link == "") ? "" : 'Link: <a href="' . $document->link . '">' . $document->link . '</a>') . '</div><div class="mdl-card__actions"><a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect" href="content.php?id1=' . $document->link . '">Show content</a></div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></button></div></div>';
        
  //$query = "SELECT id, FirstName, LastName, Email, WorkingAt, LivingIn, Birthday, StudiedAt, Link FROM OSN2 WHERE FirstName LIKE ('%". $document->fname . "%') AND LastName LIKE ('%" . $document->lname . "%') AND (Email LIKE ('%". $document->email . "%') OR Email = '') AND (WorkingAt LIKE ('%". $document->works . "%') OR WorkingAt = '') AND (LivingIn LIKE ('%". $document->lives . "%') OR LivingIn = '') AND (Birthday LIKE ('%". $document->dob . "%') OR Birthday = '') AND (StudiedAt LIKE ('%". $document->studied . "%') OR StudiedAt = '');";
  
  //echo $query . "<br /><br />";
  $ar = array();
  $regexblank = new MongoDB\BSON\Regex("");
  if ($document->fname) {
    $regex3 = new MongoDB\BSON\Regex($document->fname, "i");
    array_push($ar, ["fname" => $regex3]);
  }
  if ($document->lname) {
    $regex4 = new MongoDB\BSON\Regex($document->lname, "i");
    array_push($ar, ["lname" => $regex4]);
  }
  if ($document->email) {
    $regex5 = new MongoDB\BSON\Regex($document->email, "i");
    array_push($ar, ['$or' => [["email" => $regex5], ["email" => ""]]]);
  }
  if ($document->works) {
    $regex6 = new MongoDB\BSON\Regex($document->works, "i");
    array_push($ar, ['$or' => [["works" => $regex6], ["works" => ""]]]);
  }
  if ($document->lives) {
    $regex7 = new MongoDB\BSON\Regex($document->lives, "i");
    array_push($ar, ['$or' => [["lives" => $regex7], ["lives" => ""]]]);
  }
  if ($document->dob) {
    $regex8 = new MongoDB\BSON\Regex($document->dob, "i");
    array_push($ar, ['$or' => [["dob" => $regex8], ["dob" => ""]]]);
  }
  if ($document->studied) {
    $regex9 = new MongoDB\BSON\Regex($document->studied, "i");
    array_push($ar, ['$or' => [["studied" => $regex9], ["studied" => ""]]]);
  }
  $filter1 = [
    '$and' => $ar/*[
      ['fname' => $regex3],
      ['lname' => $regex4],
      ['email' => $regex5],
      ['works' => $regex6],
      ['lives' => $regex7],
      ['dob' => $regex8],
      ['studied' => $regex9]
    ]*/
  ];
  $options1 = [];

  $query1 = new MongoDB\Driver\Query($filter1, $options1);
  $cursor1 = $m->executeQuery('peoplefinder.osn2', $query1);
  $found = false;
  //echo "HERE";
  foreach ($cursor1 as $document1) {
    $found = true;
    $count1 = 0;
    //echo "HERE2";
    if (strtolower($document->fname) == strtolower($document1->fname)) {
      $count1++;
      $fname_match = true;
    }
    
    if (strtolower($document->lname) == strtolower($document1->lname)) {
      $count1++;
      $lname_match = true;
    }
    
    if (strtolower($document->email) == strtolower($document1->email)) {
      $count1++;
      $email_match = true;
    }
    
    if (strtolower($document->works) == strtolower($document1->works)) {
      $count1++;
      $works_match = true;
    }
    
    if (strtolower($document->lives) == strtolower($document1->lives)) {
      $count1++;
      $lives_match = true;
    }
    
    if ($document->dob == $document1->dob) {
      $count1++;
      $dob_match = true;
    }
    
    if (strtolower($document->studied) == strtolower($document1->studied)) {
      $count1++;
      $studied_match = true;
    }
    
    $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $document1->fname . " " . $document1->lname . '</h2></div><div class="mdl-card__supporting-text">' . (($document1->email == "") ? "" : 'Email: ' . $document1->email . '<br />') . (($document1->works == "") ? "" : 'Working at: ' . $document1->works . '<br />') . (($document1->lives == "") ? "" : 'Living in: ' . $document1->lives . '<br />') . (($document1->dob == "") ? "" : 'Birthday: ' . $document1->dob . '<br />') . (($document1->studied == "") ? "" : 'Studied at: ' . $document1->studied . '<br />') . (($document1->link == "") ? "" : 'Link: <a href="' . $document1->link . '">' . $document1->link . '</a>') . '</div><div class="mdl-card__actions"><a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect" href="content.php?id2=' . $document1->id . '">Show content</a></div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="linkedin-logo.png" class="osn-logo" /></button></div></div><div class="people-card mdl-shadow--2dp mdl-cell mdl-cell--12-col-desktop mdl-cell--8-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__supporting-text"><div class="profile-match">Profile match accuracy: ' . (($count1 / 7) * 100) . '%</div><div class="content_result"></div></div><div class="mdl-card__actions"><button id="' . $document->id . '" data-id="' . $document1->id . '" class="shortlist mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">Perform content matching</button></div></div>';
    break;
  }
  if (!$found) {
    $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No match on&nbsp;<img src="linkedin-logo.png" class="osn-logo" /></h2></div></div>';
  }
}
if (!$ofound) {
  $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No results!</h2></div><div class="mdl-card__supporting-text"></div></div>';
}

echo $output;

?>