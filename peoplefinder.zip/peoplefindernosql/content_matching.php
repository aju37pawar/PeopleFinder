<?php

require_once("dbconnect.php");

$id1 = $_POST["id1"];
$id2 = $_POST["id2"];

$filter = ["userid" => (int)$id1];
$options = [];
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $m->executeQuery('peoplefinder.osn1_content', $query);
$accuracies = array();
$accuracys = array();
$totals = array();
$ends = array();
foreach ($cursor as $document) {
  $content1 = $document->content;
  $filter1 = ["userid" => (int)$id2];
  $options1 = [];
  $query1 = new MongoDB\Driver\Query($filter1, $options1);
  $cursor1 = $m->executeQuery('peoplefinder.osn2_content', $query1);
  foreach ($cursor1 as $document1) {
    $content2 = $document1->content;
    $end = (strlen($content1) <= strlen($content2)) ? strlen($content1) : strlen($content2);
    array_push($ends, $end);
    $total = (strlen($content1) <= strlen($content2)) ? strlen($content2) : strlen($content1);
    array_push($totals, $total);
    $accuracy = 0;
    for ($i = 0; $i < $end; $i++) {
      $char1 = $content1[$i];
      $char2 = $content2[$i];
      if ($char1 == $char2) {
        $accuracy++;
      }
    }
    array_push($accuracys, $accuracy);
    array_push($accuracies, $accuracy / $total);
  }
}

/*$conn = createConnection();

$query = "SELECT Content, Instant FROM osn1_content WHERE UserId = ?";
$sql = $conn->prepare($query);
$sql->bind_param("i", $id1);
$sql->execute();
$result = $sql->get_result();
$accuracies = array();
$accuracys = array();
$totals = array();
$ends = array();
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $content1 = $row["Content"];
    $inner_query = "SELECT Content, Instant FROM osn2_content WHERE UserId = ?";
    $sql1 = $conn->prepare($inner_query);
    $sql1->bind_param("i", $id2);
    $sql1->execute();
    $result1 = $sql1->get_result();
    if ($result1->num_rows > 0) {
      while ($row1 = $result1->fetch_assoc()) {
        $content2 = $row1["Content"];
        $end = (strlen($content1) <= strlen($content2)) ? strlen($content1) : strlen($content2);
        array_push($ends, $end);
        $total = (strlen($content1) <= strlen($content2)) ? strlen($content2) : strlen($content1);
        array_push($totals, $total);
        $accuracy = 0;
        for ($i = 0; $i < $end; $i++) {
          $char1 = $content1[$i];
          $char2 = $content2[$i];
          if ($char1 == $char2) {
            $accuracy++;
          }
        }
        array_push($accuracys, $accuracy);
        array_push($accuracies, $accuracy / $total);
      }
    }
  }
}*/

echo json_encode($accuracies);
//echo json_encode($accuracys);
//echo json_encode($totals);
//echo json_encode($ends);

?>