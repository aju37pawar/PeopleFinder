<?php

require_once("dbconnect.php");

if (isset($_POST["search"])) {
  $fname = strtolower($_POST["fname"]);
  $lname = strtolower($_POST["lname"]);
  $email = strtolower($_POST["email"]);
  $works = strtolower($_POST["works"]);
  $lives = strtolower($_POST["lives"]);
  $dob = $_POST["dob"];
  $studied = strtolower($_POST["studied"]);
  
  $max_count = -1;
  $max_count_id = -1;
  $max_fname_match = false;
  $max_lname_match = false;
  $max_email_match = false;
  $max_works_match = false;
  $max_lives_match = false;
  $max_dob_match = false;
  $max_studied_match = false;
  
  $conn = createConnection();
  $sql = $conn->prepare("SELECT id, FirstName, LastName, Email, WorkingAt, LivingIn, FromPlace, Birthday, StudiedAt FROM OSN1 WHERE FirstName LIKE ('%". $fname . "%') AND LastName LIKE ('%" . $lname . "%') AND Email LIKE ('%". $email . "%') AND WorkingAt LIKE ('%". $works . "%') AND LivingIn LIKE ('%". $lives . "%') AND Birthday LIKE ('%". $dob . "%') AND StudiedAt LIKE ('%". $studied . "%');");
  $sql->execute();
  $result = $sql->get_result();
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $count = 0;
      $fname_match = false;
      $lname_match = false;
      $email_match = false;
      $works_match = false;
      $lives_match = false;
      $dob_match = false;
      $studied_match = false;
      
      if ($fname == strtolower($row["FirstName"])) {
        $count++;
        $fname_match = true;
      }
      if ($lname == strtolower($row["LastName"])) {
        $count++;
        $lname_match = true;
      }
      if ($email == strtolower($row["Email"])) {
        $count++;
        $email_match = true;
      }
      if ($works == strtolower($row["WorkingAt"])) {
        $count++;
        $works_match = true;
      }
      if ($lives == strtolower($row["LivingIn"])) {
        $count++;
        $lives_match = true;
      }
      if ($dob == $row["Birthday"]) {
        $count++;
        $dob_match = true;
      }
      if ($studied == strtolower($row["StudiedAt"])) {
        $count++;
        $studied_match = true;
      }
      if ($count > $max_count) {
        $max_count = $count;
        $max_count_id = $row["id"];
        $max_fname_match = $fname_match;
        $max_lname_match = $lname_match;
        $max_email_match = $email_match;
        $max_works_match = $works_match;
        $max_lives_match = $lives_match;
        $max_dob_match = $dob_match;
        $max_studied_match = $studied_match;
      }
      echo "Attributes matched exactly: " . $count . " | " . $row["FirstName"] . " " . $row["LastName"] . " " . $row["Email"] . " " . $row["WorkingAt"] . " " . $row["LivingIn"] . " " . $row["FromPlace"] . " " . $row["Birthday"] . " " . $row["StudiedAt"] . "<br />";
    }
  } else {
    echo "No results found<br />";
  }
  
  echo "================================================================================<br />Matching in OSN2:<br />";
  // To check if threshold matches are reached
  if ($max_count < 3) {
    echo "Matching threshold (3) not reached!<br />";
  } else {
    $sql = $conn->prepare("SELECT FirstName, LastName, Email, WorkingAt, LivingIn, FromPlace, Birthday, StudiedAt FROM OSN1 WHERE id = ?");
    $sql->bind_param("i", $max_count_id);
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      $max_fname = strtolower($row["FirstName"]);
      $max_lname = strtolower($row["LastName"]);
      $max_email = strtolower($row["Email"]);
      $max_works = strtolower($row["WorkingAt"]);
      $max_lives = strtolower($row["LivingIn"]);
      $max_dob = strtolower($row["Birthday"]);
      $max_studied = strtolower($row["StudiedAt"]);
      
      $query = "SELECT FirstName, LastName, Email, WorkingAt, LivingIn, Birthday, StudiedAt FROM OSN2 WHERE ";
      $started = false;
      
      if ($max_fname_match) {
        $query .= "FirstName LIKE ('%" . $max_fname . "%') ";
        $started = true;
      }
      
      if ($started && $max_lname_match) {
        $query .= "AND ";
      }
      if ($max_lname_match) {
        $query .= "LastName LIKE ('%" . $max_lname. "%') ";
        $started = true;
      }
      
      if ($started && $max_email_match) {
        $query .= "AND ";
      }
      if ($max_email_match) {
        $query .= "Email LIKE ('%" . $max_email . "%') ";
        $started = true;
      }
      
      if ($started && $max_works_match) {
        $query .= "AND ";
      }
      if ($max_works_match) {
        $query .= "WorkingAt LIKE ('%" . $max_works. "%') ";
        $started = true;
      }
      
      if ($started && $max_lives_match) {
        $query .= "AND ";
      }
      if ($max_lives_match) {
        $query .= "LivingIn LIKE ('%" . $max_lives . "%') ";
        $started = true;
      }
      
      if ($started && $max_dob_match) {
        $query .= "AND ";
      }
      if ($max_dob_match) {
        $query .= "Birthday LIKE ('%" . $max_dob . "%') ";
        $started = true;
      }
      
      if ($started && $max_studied_match) {
        $query .= "AND ";
      }
      if ($max_studied_match) {
        $query .= "StudiedAt LIKE ('%" . $max_studied . "%');";
        $started = true;
      }
      echo $query . "<br /><br />";
      /*if (!($max_fname_match && $max_lname_match && $max_email_match && $max_works_match && $max_lives_match && $max_dob_match && $max_studied_match)) {
        
      }*/
      $sql = $conn->prepare($query);
      $sql->execute();
      $result = $sql->get_result();
      if ($result->num_rows > 0) {
        echo "Match found in OSN2:<br />" . $row["FirstName"] . " " . $row["LastName"] . " " . $row["Email"] . " " . $row["WorkingAt"] . " " . $row["LivingIn"] . " " . $row["Birthday"] . " " . $row["StudiedAt"] . "<br />";
      } else {
        echo "No matches found in OSN2<br />";
      }
    } else {
      echo "No results found<br />";
    }
  }
  
  $conn->close();
  
  /*if ($name != "") {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%');");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $count++;
      $name_match = true;
      echo "Count is " . $count . "<br />";
    }
  }
  if ($email != "") {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND Email LIKE ('%" . $email . "%');");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $count++;
      $email_match = true;
      echo "Count is " . $count . "<br />";
    }
  }
  if ($works != "") {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND WorkingAt LIKE ('%" . $works . "%');");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $count++;
      $works_match = true;
      echo "Count is " . $count . "<br />";
    }
  }
  if ($lives != "") {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND LivingIn LIKE ('%" . $lives . "%');");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $count++;
      $lives_match = true;
      echo "Count is " . $count . "<br />";
    }
  }
  if ($dob != "") {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND Birthday = '" . $dob . "';");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $count++;
      $dob_match = true;
      echo "Count is " . $count . "<br />";
    }
  }
  if ($studied != "") {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND StudiedAt LIKE ('%" . $studied . "%');");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      $count++;
      $studied_match = true;
      echo "Count is " . $count . "<br />";
    }
  }
  
  if ($name_match) {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%');");
    if ($lives_match) {
      $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND LivingIn LIKE ('%" . $lives . "%');");
      if ($studied_match) {
        $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND LivingIn LIKE ('%" . $lives . "%') AND StudiedAt LIKE ('%" . $studied . "%');");
      }
    }
    echo "\nMatch is<br />";
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo $row["Name"] . " " . $row["Email"] . " " . $row["WorkingAt"] . " " . $row["LivingIn"] . " " . $row["StudiedAt"] . "<br />";
      }
    }
  }*/
  
  /*if ($name_match && $email_match && ($works_match || $lives_match || $studied_match || $dob_match)) {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND Email LIKE ('%" . $email . "%');");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "\nMatch is" . $row["Name"] . " " . $row["Email"] . " " . $row["WorkingAt"] . " " . $row["LivingIn"] . " " . $row["StudiedAt"];
      }
    }
  } else if ($name_match && ($email_match || $works_match || $lives_match || $studied_match || $dob_match)) {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%');");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "\nMatch is" . $row["Name"] . " " . $row["Email"] . " " . $row["WorkingAt"] . " " . $row["LivingIn"] . " " . $row["StudiedAt"];
      }
    }
  } else if ($name_match && $dob_match && ($email_match || $works_match || $lives_match || $studied_match)) {
    $sql = $conn->prepare("SELECT * FROM OSN1 WHERE Name LIKE ('%" . $name . "%') AND Birthday = '" . $dob . "';");
    $sql->execute();
    $result = $sql->get_result();
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "\nMatch is" . $row["Name"] . " " . $row["Email"] . " " . $row["WorkingAt"] . " " . $row["LivingIn"] . " " . $row["StudiedAt"];
      }
    }
  } else {
    
  }*/
}

?>