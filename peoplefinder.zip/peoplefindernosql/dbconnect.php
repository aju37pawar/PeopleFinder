<?php

$m = new MongoDB\Driver\Manager("mongodb://localhost:27017/peoplefinder");

?>