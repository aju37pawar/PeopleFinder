<?php

require_once("dbconnect.php");

$output = "";
$persons = "";
$id1 = 0;
$id2 = 0;
if (isset($_GET["id1"]) || isset($_GET["id2"])) {
  $id1 = isset($_GET["id1"]) ? $_GET["id1"] : 0;
  $id2 = isset($_GET["id2"]) ? $_GET["id2"] : 0;
  
  if ($id2 != 0) {
    $id1 = $_GET["id1"];
    $id2 = $_GET["id2"];
    $regex = new MongoDB\BSON\Regex($id1);
    $filter = ["id" => (int)$id1];
    $options = [];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $m->executeQuery('peoplefinder.osn1', $query);
    $ofound = false;
    //var_dump($cursor);
    foreach ($cursor as $document) {
      $ofound = true;
      $persons .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $document->fname . " " . $document->lname . '</h2></div><div class="mdl-card__supporting-text">' . (($document->email == "") ? "" : 'Email: ' . $document->email . '<br />') . (($document->works == "") ? "" : 'Working at: ' . $document->works . '<br />') . (($document->lives == "") ? "" : 'Living in: ' . $document->lives . '<br />') . (($document->dob == "") ? "" : 'Birthday: ' . $document->dob . '<br />') . (($document->studied == "") ? "" : 'Studied at: ' . $document->studied . '<br />') . (($document->link == "") ? "" : 'Link: <a href="' . $document->link . '">' . $document->link . '</a>') . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></button></div></div>';
      
      //$query = "SELECT id, FirstName, LastName, Email, WorkingAt, LivingIn, Birthday, StudiedAt, Link FROM OSN2 WHERE FirstName LIKE ('%". $document->fname . "%') AND LastName LIKE ('%" . $document->lname . "%') AND (Email LIKE ('%". $document->email . "%') OR Email = '') AND (WorkingAt LIKE ('%". $document->works . "%') OR WorkingAt = '') AND (LivingIn LIKE ('%". $document->lives . "%') OR LivingIn = '') AND (Birthday LIKE ('%". $document->dob . "%') OR Birthday = '') AND (StudiedAt LIKE ('%". $document->studied . "%') OR StudiedAt = '');";
      $ar = array();
      $regexblank = new MongoDB\BSON\Regex("");
      if ($document->fname) {
        $regex3 = new MongoDB\BSON\Regex($document->fname, "i");
        array_push($ar, ["fname" => $regex3]);
      }
      if ($document->lname) {
        $regex4 = new MongoDB\BSON\Regex($document->lname, "i");
        array_push($ar, ["lname" => $regex4]);
      }
      if ($document->email) {
        $regex5 = new MongoDB\BSON\Regex($document->email, "i");
        array_push($ar, ['$or' => [["email" => $regex5], ["email" => ""]]]);
      }
      if ($document->works) {
        $regex6 = new MongoDB\BSON\Regex($document->works, "i");
        array_push($ar, ['$or' => [["works" => $regex6], ["works" => ""]]]);
      }
      if ($document->lives) {
        $regex7 = new MongoDB\BSON\Regex($document->lives, "i");
        array_push($ar, ['$or' => [["lives" => $regex7], ["lives" => ""]]]);
      }
      if ($document->dob) {
        $regex8 = new MongoDB\BSON\Regex($document->dob, "i");
        array_push($ar, ['$or' => [["dob" => $regex8], ["dob" => ""]]]);
      }
      if ($document->studied) {
        $regex9 = new MongoDB\BSON\Regex($document->studied, "i");
        array_push($ar, ['$or' => [["studied" => $regex9], ["studied" => ""]]]);
      }
      $filter1 = [
        '$and' => $ar/*[
          ['fname' => $regex3],
          ['lname' => $regex4],
          ['email' => $regex5],
          ['works' => $regex6],
          ['lives' => $regex7],
          ['dob' => $regex8],
          ['studied' => $regex9]
        ]*/
      ];
      $options1 = [];

      $query1 = new MongoDB\Driver\Query($filter1, $options1);
      $cursor1 = $m->executeQuery('peoplefinder.osn2', $query1);
      $found = false;
      //echo "HERE";
      $found = false;
      foreach ($cursor1 as $document1) {
        $found = true;
        $persons .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $document1->fname . " " . $document1->lname . '</h2></div><div class="mdl-card__supporting-text">' . (($document1->email == "") ? "" : 'Email: ' . $document1->email . '<br />') . (($document1->works == "") ? "" : 'Working at: ' . $document1->works . '<br />') . (($document1->lives == "") ? "" : 'Living in: ' . $document1->lives . '<br />') . (($document1->dob == "") ? "" : 'Birthday: ' . $document1->dob . '<br />') . (($document1->studied == "") ? "" : 'Studied at: ' . $document1->studied . '<br />') . (($document1->link == "") ? "" : 'Link: <a href="' . $document1->link . '">' . $document1->link . '</a>') . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="linkedin-logo.png" class="osn-logo" /></button></div></div>';
        break;
      }
      
      $filter2 = ["userid" => (int)$id2];
      $options2 = [];

      $query2 = new MongoDB\Driver\Query($filter2, $options2);
      $cursor2 = $m->executeQuery('peoplefinder.osn2_content', $query2);
      $pfound = false;
      foreach ($cursor2 as $document2) {
        $pfound = true;
        $instant = date_create_from_format('Y-m-d H:i:s', $document2->instant);
        $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $instant->format("d F Y | h:i A") . '</h2></div><div class="mdl-card__supporting-text">' . $document2->content . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="linkedin-logo.png" class="osn-logo" /></button></div></div>';
      }
      if (!$pfound) {
        $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No posts on&nbsp;<img src="linkedin-logo.png" class="osn-logo" /></h2></div></div>';
      }
      break;
    }
  } else if ($id1 != 0) {
    $id1 = $_GET["id1"];
    $regex = new MongoDB\BSON\Regex($id1);
    $filter = ["id" => (int)$id1];
    $options = [];
    $query = new MongoDB\Driver\Query($filter, $options);
    $cursor = $m->executeQuery('peoplefinder.osn1', $query);
    $ofound = false;
    //var_dump($cursor);
    foreach ($cursor as $document) {
      $ofound = true;
      $persons .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $document->fname . " " . $document->lname . '</h2></div><div class="mdl-card__supporting-text">' . (($document->email == "") ? "" : 'Email: ' . $document->email . '<br />') . (($document->works == "") ? "" : 'Working at: ' . $document->works . '<br />') . (($document->lives == "") ? "" : 'Living in: ' . $document->lives . '<br />') . (($document->dob == "") ? "" : 'Birthday: ' . $document->dob . '<br />') . (($document->studied == "") ? "" : 'Studied at: ' . $document->studied . '<br />') . (($document->link == "") ? "" : 'Link: <a href="' . $document->link . '">' . $document->link . '</a>') . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></button></div></div>';
      
      //$query = "SELECT id, FirstName, LastName, Email, WorkingAt, LivingIn, Birthday, StudiedAt, Link FROM OSN2 WHERE FirstName LIKE ('%". $document->fname . "%') AND LastName LIKE ('%" . $document->lname . "%') AND (Email LIKE ('%". $document->email . "%') OR Email = '') AND (WorkingAt LIKE ('%". $document->works . "%') OR WorkingAt = '') AND (LivingIn LIKE ('%". $document->lives . "%') OR LivingIn = '') AND (Birthday LIKE ('%". $document->dob . "%') OR Birthday = '') AND (StudiedAt LIKE ('%". $document->studied . "%') OR StudiedAt = '');";
      $ar = array();
      $regexblank = new MongoDB\BSON\Regex("");
      if ($document->fname) {
        $regex3 = new MongoDB\BSON\Regex($document->fname, "i");
        array_push($ar, ["fname" => $regex3]);
      }
      if ($document->lname) {
        $regex4 = new MongoDB\BSON\Regex($document->lname, "i");
        array_push($ar, ["lname" => $regex4]);
      }
      if ($document->email) {
        $regex5 = new MongoDB\BSON\Regex($document->email, "i");
        array_push($ar, ['$or' => [["email" => $regex5], ["email" => ""]]]);
      }
      if ($document->works) {
        $regex6 = new MongoDB\BSON\Regex($document->works, "i");
        array_push($ar, ['$or' => [["works" => $regex6], ["works" => ""]]]);
      }
      if ($document->lives) {
        $regex7 = new MongoDB\BSON\Regex($document->lives, "i");
        array_push($ar, ['$or' => [["lives" => $regex7], ["lives" => ""]]]);
      }
      if ($document->dob) {
        $regex8 = new MongoDB\BSON\Regex($document->dob, "i");
        array_push($ar, ['$or' => [["dob" => $regex8], ["dob" => ""]]]);
      }
      if ($document->studied) {
        $regex9 = new MongoDB\BSON\Regex($document->studied, "i");
        array_push($ar, ['$or' => [["studied" => $regex9], ["studied" => ""]]]);
      }
      $filter1 = [
        '$and' => $ar/*[
          ['fname' => $regex3],
          ['lname' => $regex4],
          ['email' => $regex5],
          ['works' => $regex6],
          ['lives' => $regex7],
          ['dob' => $regex8],
          ['studied' => $regex9]
        ]*/
      ];
      $options1 = [];

      $query1 = new MongoDB\Driver\Query($filter1, $options1);
      $cursor1 = $m->executeQuery('peoplefinder.osn2', $query1);
      $found = false;
      //echo "HERE";
      $found = false;
      foreach ($cursor1 as $document1) {
        $id2 = $document1->id;
        $found = true;
        $persons .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $document1->fname . " " . $document1->lname . '</h2></div><div class="mdl-card__supporting-text">' . (($document1->email == "") ? "" : 'Email: ' . $document1->email . '<br />') . (($document1->works == "") ? "" : 'Working at: ' . $document1->works . '<br />') . (($document1->lives == "") ? "" : 'Living in: ' . $document1->lives . '<br />') . (($document1->dob == "") ? "" : 'Birthday: ' . $document1->dob . '<br />') . (($document1->studied == "") ? "" : 'Studied at: ' . $document1->studied . '<br />') . (($document1->link == "") ? "" : 'Link: <a href="' . $document1->link . '">' . $document1->link . '</a>') . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="linkedin-logo.png" class="osn-logo" /></button></div></div>';
        break;
      }
      
      $filter2 = ["userid" => (int)$id1];
      $options2 = [];

      $query2 = new MongoDB\Driver\Query($filter2, $options2);
      $cursor2 = $m->executeQuery('peoplefinder.osn1_content', $query2);
      $pfound = false;
      foreach ($cursor2 as $document2) {
        $pfound = true;
        $instant = date_create_from_format('Y-m-d H:i:s', $document2->instant);
        $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">' . $instant->format("d F Y | h:i A") . '</h2></div><div class="mdl-card__supporting-text">' . $document2->content . '</div><div class="mdl-card__menu"><button class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect"><img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></button></div></div>';
      }
      if (!$pfound) {
        $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">No posts on&nbsp;<img src="facebook-logo-png-transparent-background-1.png" class="osn-logo" /></h2></div></div>';
      }
      break;
    }
  }
  if (!$ofound) {
    $output .= '<div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--6-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone"><div class="mdl-card__title"><h2 class="mdl-card__title-text">Nothing to show!</h2></div></div>';
  }
  
}

?>

<!DOCTYPE html>

<html>
  <head>
    <title>Content Matcher | People Finder</title>
    <link rel="stylesheet" type="text/css" href="master.css" />
    <link rel="stylesheet" type="text/css" href="material.min.css" />
    <link rel="stylesheet" type="text/css" href="iconfont/material-icons.css" />
    <script src="jquery-3.2.1.min.js"></script>
    <script src="material.min.js"></script>
  </head>
  <body>
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
      <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title"><a class="mdl-button mdl-js-button mdl-button--fab mdl-button--mini-fab mdl-button--colored" href="index.php"><i class="material-icons">home</i></a>&nbsp;&nbsp;Content</span>
          <div class="mdl-layout-spacer"></div>
          <nav class="mdl-navigation mdl-layout--large-screen-only">
            <a class="mdl-navigation__link" href="aboutus.html">ABOUT US</a>
          </nav>
        </div>        
      </header>
      <main class="mdl-layout__content">
        <div class="page-content">
          <div class="mdl-grid">
            <?php echo $persons; ?>
          </div>
          <h3>Filters <button class="mdl-button mdl-js-button mdl-button--fab mdl-button--mini-fab mdl-button--colored" id="filter-toggle"><i class="material-icons" id="filter-toggle-icon">add</i></button></h3>
          <form id="filter-form" class="mdl-shadow--2dp" style="display: none;">
            <div>
              <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                <input type="text" name="content" id="content" class="mdl-textfield__input" />
                <label class="mdl-textfield__label" for="content">Content...</label>
              </div>
              <input type="hidden" name="search" value="search" />
              <input type="hidden" name="id1" value="<?php echo $id1 ?>" />
              <input type="hidden" name="id2" value="<?php echo $id2 ?>" />
              <button class="mdl-button mdl-js-button mdl-button--icon mdl-button--colored" type="submit">
                <i class="material-icons">search</i>
              </button>
              <button class="mdl-button mdl-js-button mdl-button--icon mdl-button--colored" id="clear-form" type="reset">
                <i class="material-icons">close</i>
              </button>
            </div>
          </form>
          <h3>Results</h3>
          <div class="mdl-grid" id="result-holder">
            <?php echo $output; ?>
          </div>
        </div>
      </main>
    </div>
    <script>
      var filterOn = false;
      
      $("#filter-form").submit(function (event) {
        event.preventDefault();
        
        $.ajax({
          url: "content1.php",
          contentType: "application/x-www-form-urlencoded",
          data: $("#filter-form").serialize(),
          error: function (err) {
            alert("Some error occured");
          },
          method: "POST",
          success: function (data) {
            document.getElementById("result-holder").innerHTML = data;
          }
        });
      });
      
      document.getElementById("clear-form").addEventListener("click", function () {
        /*document.getElementById("fname").value = "";
        document.getElementById("lname").value = "";
        document.getElementById("email").value = "";
        document.getElementById("works").value = "";
        document.getElementById("lives").value = "";
        document.getElementById("dob").value = "";
        document.getElementById("studied").value = "";*/
        document.getElementById("content").focus();
      });
      
      document.getElementById("filter-toggle").addEventListener("click", function () {
        if (filterOn) {
          document.getElementById("filter-form").setAttribute("style", "display: none;");
          filterOn = !filterOn;
          document.getElementById("filter-toggle-icon").innerHTML = "add";
        } else {
          document.getElementById("filter-form").setAttribute("style", "display: block;");
          filterOn = !filterOn;
          document.getElementById("filter-toggle-icon").innerHTML = "remove";
          document.getElementById("content").focus();
        }
      });
    </script>
  </body>
</html>